# प्रज्ञसंस्कार

A Pen created on CodePen.

Original URL: [https://codepen.io/Be-You-the-animator/pen/ZYzNgRN](https://codepen.io/Be-You-the-animator/pen/ZYzNgRN).

