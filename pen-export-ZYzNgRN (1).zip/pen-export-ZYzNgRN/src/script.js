document.addEventListener("DOMContentLoaded", function () {
    const sections = document.querySelectorAll(".activity-section");

    sections.forEach(section => {
        section.addEventListener("click", function () {
            const content = this.querySelector(".activity-content");

            // Close other sections if needed
            sections.forEach(sec => {
                if (sec !== this) {
                    sec.querySelector(".activity-content").style.display = "none";
                    sec.classList.remove("active");
                }
            });

            // Toggle this section
            if (content.style.display === "block") {
                content.style.display = "none";
                section.classList.remove("active");
            } else {
                content.style.display = "block";
                section.classList.add("active");
            }
        });
    });
});
